<footer>
    <nav>
        <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/support">Support</a></li>
            <li><a href="/documentation">Documentation</a></li>
            <li><a href="/about">About</a></li>
        </ul>
    </nav>
    <p>&copy; 1997 bollwerk</p>
</footer>

</body>
</html>
