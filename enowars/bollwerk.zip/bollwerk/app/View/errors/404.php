<?php require(resolvePath('View/partials/head.php')) ?>

<?php require(resolvePath('View/partials/navigation.php')) ?>

<div>
    <div class="page-container">Page not found</div>
</div>

<?php require(resolvePath('View/partials/footer.php')) ?>
