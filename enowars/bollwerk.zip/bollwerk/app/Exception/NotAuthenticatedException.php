<?php

namespace Exception;

use RuntimeException;

class NotAuthenticatedException extends RuntimeException
{
}